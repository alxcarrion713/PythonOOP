class Bankaccount:		# declare a class and give it name User
    def __init__(self,int_rate,balance):
        self.interest_rate = int_rate
        self.balance = balance


    def make_deposit(self, amount):	
    	self.balance += amount
        print(amount)
        return self
        
    def make_withdrawal(self,amount):
        if self.balance >=amount:
            print(amount)
        else:
            print("insufficient funds")
        self.balance -= 5
        return self


    def display_account_info(self,amount):
        self.balance= amount
        return self
        

    def interest_yield(self):
        if self.balance>0:
            self.balance= self.balance + (self.balance * self.interest_rate)
        return self


Account1=Bankaccount(0.5,0)
Account1.make_deposit(100).interest_yield().make_withdrawal(50)